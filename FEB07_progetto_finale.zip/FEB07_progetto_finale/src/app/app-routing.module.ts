import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClientiComponent } from './components/clienti.component';
import { HomeComponent } from './components/home.component';
import { ListaUtentiComponent } from './components/lista-utenti.component';
import { LoginComponent } from './components/login.component';
import { SignupComponent } from './components/signUp.component';
import { AuthGuard } from './auth.guard';
import { DettagliFatturaPage } from './components/dettagli-fattura.page';
import { DettagliClienteComponent } from './components/dettagli-clienti.component';
import { ModificaClienteComponent } from './components/modifica-cliente.component';
import { NewFatturaPage } from './components/new-fattura.page';
import { FatturePage } from './components/fatture.page';
import { FattureClientePage } from './components/fatture-cliente.page';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'signup',
    component: SignupComponent,
  },
  {
    path: 'lista',
    component: ListaUtentiComponent,
  },
  {
    path: 'clienti',
    component: ClientiComponent,
    canActivate: [AuthGuard],
  },

  {
    path: 'fatture',
    component: FatturePage,
    canActivate: [AuthGuard],
  },

  {
    path: 'dettagliClienti',
    component: DettagliClienteComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'dettagliFattura/:id',
    component: DettagliFatturaPage,
    canActivate: [AuthGuard],
  },

  {
    path: 'fattureCliente/:id',
    component: FattureClientePage,
    canActivate: [AuthGuard],
  },

  {
    path: 'newFattura/:id',
    component: NewFatturaPage,
    canActivate: [AuthGuard],
  },

  {
    path: 'newFattura',
    component: NewFatturaPage,
  },

  {
    path: 'modificaCliente/:id',
    component: ModificaClienteComponent,
    canActivate: [AuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
