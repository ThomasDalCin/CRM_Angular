export class AdminLogin {
  email: string = 'admin';
  password: string = '111111';
}
