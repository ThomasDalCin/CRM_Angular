import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { SignUpService } from 'src/app/services/sign-up.service';

@Component({
  template: `
    <div class="myContainer">
      <div class="row justify-content-center ">
        <div class="col-sm-6">
          <form #form="ngForm" (ngSubmit)="onsignup(form)">
            <div class="form-group">
              <label for="username">Username:</label>
              <input
                placeholder="Username personale"
                ngModel
                name="username"
                class="form-control"
                type="username"
                id="username"
              />
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input
                placeholder="Email personale"
                ngModel
                name="email"
                class="form-control"
                type="email"
                id="email"
              />
            </div>
            <div class="form-group">
              <label for="password">Password:</label>
              <input
                placeholder="Minimo 6 caratteri!"
                ngModel
                name="password"
                class="form-control"
                type="password"
                id="password"
              />
            </div>

            <label>Seleziona il tuo ruolo:</label>
            <select ngModel name="ruolo" class="form-select">
              <option selected></option>
              <option value="ROLE_USER">Utente</option>
              <option value="ROLE_ADMIN">Amministratore</option>
            </select>

            <button
              class="btn btn-primary mt-3"
              [disabled]="false"
              type="submit"
            >
              Registrati
            </button>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .myContainer {
        margin: 10vh auto;
        padding: 40px 40px;
        width: 70vw;
        border-radius: 10px;
        background-color: whitesmoke;
      }
      .myContainer:hover {
        box-shadow: 0 0 10px 0 #3498db inset, 0 0 10px 4px #3498db;
      }
      label {
        font-weight: bolder;
        margin: 10px 10px;
        font-size: larger;
      }

      ::placeholder {
        color: #88acfa;
        opacity: 0.8;
        font-style: italic;
      }

      input,
      select {
        border: 1px solid #88acfa;
      }

      .btn-primary:hover {
        background-color: #88acfa;
        border: 0.5px solid black;
        color: whitesmoke;
      }
    `,
  ],
})
export class SignupComponent implements OnInit {
  constructor(private signSrv: SignUpService, private router: Router) {}

  ngOnInit(): void {}

  onsignup(form: NgForm) {
    this.signSrv.signup(form.value).subscribe((res) => {
      alert('Ti sei registrato!');
      console.log(res);
      this.router.navigate(['/login']);
    });
  }
}
