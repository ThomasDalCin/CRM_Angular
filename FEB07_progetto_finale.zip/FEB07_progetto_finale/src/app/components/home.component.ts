import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  template: `
    <div class="container">
      <div class="row">
        <div class="col-sm mt-5">
          <h2>FE07B-PROGETTO FINALE</h2>
          <p>
            Questa Web-app è stata realizzata didatticamente con lo scopo di
            mettere in pratica quello che è stato appreso durante il corso
            Epicode, in particolare utilizzando il framework ANGULAR.<br />
            Simulerà un gestionale fatture per aziende.
          </p>
          <p>Effettua il sign-up in modo da accedervi!</p>
          <button class=" btn btn-primary myButton" (click)="vai()">Vai</button>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      h2 {
        font-weight: bolder;
        text-shadow: -1px 0 rgb(136, 172, 250), 0 1px rgb(136, 172, 250),
          1px 0 rgb(136, 172, 250), 0 -1px rgb(136, 172, 250);
        margin-bottom: 20px;
      }

      .container {
        text-align: justify;
        margin: 20vh auto;
        padding: 30px 30px;
        background-color: whitesmoke;
        border-radius: 10px;
        text-align: center;
      }

      .container:hover {
        box-shadow: 0 0 10px 0 #3498db inset, 0 0 10px 4px #3498db;
      }

      p {
        text-transform: uppercase;
        font-weight: bold;
        margin-bottom: 30px;
      }

      .myButton {
        border-color: #3498db;
        color: #fff;
        box-shadow: 0 0 40px 40px #3498db inset, 0 0 0 0 #3498db;
        transition: all 150ms ease-in-out;
        width: 70px;
      }

      .myButton:hover {
        box-shadow: 0 0 10px 0 #3498db inset, 0 0 10px 4px #3498db;
      }
    `,
  ],
})
export class HomeComponent implements OnInit {
  constructor(private router: Router) {}

  vai() {
    this.router.navigate(['/signup']);
  }
  ngOnInit(): void {}
}
