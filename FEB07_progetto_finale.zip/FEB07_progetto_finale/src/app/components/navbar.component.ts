import { Component, OnInit } from '@angular/core';
import { User } from '../models/users';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-navbar',
  template: `
    <nav class="navbar navbar-expand-lg myNav">
      <div class="container-fluid">
        <button
          class="navbar-toggler"
          type="button"
          (click)="isMenuCollapsed = !isMenuCollapsed"
        >
          &#9776;
        </button>
        <div
          [ngbCollapse]="isMenuCollapsed"
          class="collapse navbar-collapse justify-content-start"
        >
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a
                class="nav-link"
                (click)="isMenuCollapsed = true"
                [routerLink]="['/']"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: true }"
                >Home</a
              >
            </li>
            <li *ngIf="!user" class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/login']"
                routerLinkActive="active"
              >
                Login</a
              >
            </li>
            <li *ngIf="!user" class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/signup']"
                routerLinkActive="active"
              >
                SignUp</a
              >
            </li>
            <li
              *ngIf="!user"
              class="nav-item"
              [routerLink]="['/lista']"
              routerLinkActive="active"
            >
              <a class="nav-link"> Lista Utenti</a>
            </li>

            <li
              *ngIf="user"
              class="nav-item"
              [routerLink]="['/clienti']"
              routerLinkActive="active"
            >
              <a class="nav-link"> Clienti</a>
            </li>
            <li
              *ngIf="user"
              class="nav-item"
              [routerLink]="['/fatture']"
              routerLinkActive="active"
            >
              <a class="nav-link"> Fatture</a>
            </li>
          </ul>
        </div>
        <div class="justify-content-end">
          <button class="btn btn-success">Logout</button>
        </div>
      </div>
    </nav>
  `,
  styles: [
    `
      .myNav {
        background: linear-gradient(to right, #373b44, #4286f4);
        border-bottom: 2px solid white;
      }
      a {
        color: white;
        text-decoration: none;
      }
      a:hover {
        cursor: pointer;
        color: purple !important;
        font-size: 20px;
      }
    `,
  ],
})
export class NavbarComponent implements OnInit {
  isMenuCollapsed = false;
  user!: User | null;
  constructor(private authSrv: LoginService) {}
  user$ = this.authSrv.user$;
  ngOnInit(): void {
    this.authSrv.user$.subscribe((user) => {
      this.user = user;
    });
  }
  logout() {
    this.authSrv.logout();
  }
}
