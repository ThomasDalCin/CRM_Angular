import { Component, OnInit } from '@angular/core';
import { User } from '../models/users';
import { UserService } from '../services/users.service';

@Component({
  template: `
    <div class="container mt-4 mb-4 myContainer">
      <div class="row">
        <div class="col-md-12">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Ruoli</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let user of users">
                <td>{{ user.id }}</td>
                <td>{{ user.username }}</td>
                <td>{{ user.email }}</td>
                <td>
                  <span class="btn" *ngFor="let item of user.roles">{{
                    item.roleName
                  }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .myContainer {
        padding: 40px 40px;
        width: 70vw;
        border-radius: 10px;
        background-color: whitesmoke;
      }
      .myContainer:hover {
        box-shadow: 0 0 10px 0 #3498db inset, 0 0 10px 4px #3498db;
      }
      label {
        font-weight: bolder;
        margin: 10px 10px;
        font-size: larger;
      }

      ::placeholder {
        color: #88acfa;
        opacity: 0.8;
        font-style: italic;
      }
    `,
  ],
})
export class ListaUtentiComponent implements OnInit {
  users!: Array<User>;

  constructor(private usrSrv: UserService) {}

  ngOnInit(): void {
    this.usrSrv.getAll().subscribe((res) => {
      this.users = res.content;
    });
  }
}
