import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NavbarComponent } from './components/navbar.component';
import { HomeComponent } from './components/home.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MyHttpInterceptor } from './interceptor/http-interceptor';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './components/login.component';
import { SignupComponent } from './components/signUp.component';

import { ClientiComponent } from './components/clienti.component';
import { ListaUtentiComponent } from './components/lista-utenti.component';
import { DettagliClienteComponent } from './components/dettagli-clienti.component';
import { ModificaClienteComponent } from './components/modifica-cliente.component';
import { FatturePage } from './components/fatture.page';
import { FattureClientePage } from './components/fatture-cliente.page';
import { DettagliFatturaPage } from './components/dettagli-fattura.page';
import { NewFatturaPage } from './components/new-fattura.page';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    ClientiComponent,
    ListaUtentiComponent,
    DettagliClienteComponent,
    ModificaClienteComponent,
    FatturePage,
    FattureClientePage,
    DettagliFatturaPage,
    NewFatturaPage,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MyHttpInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
